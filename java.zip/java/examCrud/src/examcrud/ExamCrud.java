/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examcrud;

/**
 *
 * @author dhruv
 */
import java.util.*;
import java.sql.*;

public class ExamCrud {

    
    /**
     * @param args the command line arguments
     */
 
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner s = new Scanner(System.in);
        
        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/exam","root","");
            int ch;
            
            do {                
                System.out.println("1. INSERT \n2. UPDATE \n3. DELETE \n4. DISPLAY \n0. EXIT");
                
                System.out.println("Enter Choice : ");
                ch = s.nextInt();
                
                switch (ch) {
                    case 1:
                        //INSERT: 
                
                            System.out.println("Enter Name : ");
                            String name = s.next();
                            System.out.println("Enter Age : ");
                            int age = s.nextInt();
                            System.out.println("Enter Email : ");
                            String email = s.next();

                            PreparedStatement ps = con.prepareStatement("INSERT into emp (name,age,email) VALUES (?,?,?)");


                            ps.setString(1, name);
                            ps.setInt(2, age);
                            ps.setString(3, email);

                            int row = ps.executeUpdate();

                            if(row>0)
                            {
                                System.out.println("Data Inserted..");
                            }
                            else
                            {
                                System.out.println("Data Does not Inserted");
                            }
                        break;
                    case 2:
                        //UPDATE :
            
                        
                            System.out.println("Enter ID :  ");
                            int id = s.nextInt();

                            System.out.println("Enter Updated Age :  ");
                            int uage = s.nextInt();

                            System.out.println("Enter Updated Name : ");
                            String uname = s.next();

                            PreparedStatement psu = con.prepareStatement("UPDATE emp SET name=?, age=? where id=?");

                            psu.setInt(2, uage);
                            psu.setString(1, uname);
                            psu.setInt(3, id);

                            psu.executeUpdate();
                        break;
                    case 3:
                         //DELETE : 
            
                        System.out.println("Enter ID :  ");
                        int eid = s.nextInt();

                        PreparedStatement psd = con.prepareStatement("DELETE from emp where id=?");
                        psd.setInt(1, eid);

                        psd.executeUpdate();
                        break;
                    case 4:
                        //DISPLAY : 
        
                        Statement st = con.createStatement();
                        ResultSet rs = st.executeQuery("SELECT * from emp");

                        while(rs.next())
                        {
                            System.out.println("Name : "+rs.getString("name")+"\n"+ "Age : "+rs.getInt("age")+"\n"+"Email : "+rs.getString("email"));
                        }
                        break;
                    case 0:
                        System.exit(0);
                    default:
                        throw new AssertionError();
                }
            } while (true);        

           

            
            
            
           
            
            
        } catch (Exception e) {
            System.out.println(e);
        }
        
        
    }
    
}
