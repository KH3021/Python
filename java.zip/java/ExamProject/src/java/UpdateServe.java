import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class UpdateServe extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String email = request.getParameter("email");

        try (PrintWriter out = response.getWriter()) {

            // basic validation
            if (id == null || id.trim().isEmpty()) {
                out.println("Missing id parameter");
                return;
            }

            // optional: ensure numeric id
            int iid;
            try {
                iid = Integer.parseInt(id);
            } catch (NumberFormatException nfe) {
                out.println("Invalid id format");
                return;
            }

            // DB connection info
            String jdbcUrl = "jdbc:mysql://localhost:3306/exampro";
            String dbUser = "root";
            String dbPass = "";

            Class.forName("com.mysql.cj.jdbc.Driver");

            String sql = "UPDATE employee SET name = ?, age = ?, email = ? WHERE id = ?";

            try (Connection con = DriverManager.getConnection(jdbcUrl, dbUser, dbPass);
                 PreparedStatement prt = con.prepareStatement(sql)) {

                prt.setString(1, name);
                prt.setString(2, age);
                prt.setString(3, email);
                prt.setInt(4, iid);

                int row = prt.executeUpdate();

                if (row > 0) {
                    out.println("Data Updated successfully for id = " + iid);
                } else {
                    out.println("No record found with id = " + iid);
                }
            } catch (SQLException sqle) {
                out.println("Database error: " + sqle.getMessage());
            }

        } catch (ClassNotFoundException cnfe) {
            throw new ServletException("JDBC driver not found", cnfe);
        }
    }

    @Override
    public String getServletInfo() {
        return "UpdateServe - update employee record";
    }
}
